-- name = "Timer"
-- type = "module"
-- retui = "1"
-- description = "System timer module backed by Re:T-UI clock state"

local clock = require "clock"
local fmt = require "fmt"

local BAR_WIDTH = 14

local function ms(value)
    local n = tonumber(value or 0) or 0
    return math.max(0, n)
end

local function duration(value)
    return clock:format_duration(ms(value))
end

local function pct(elapsed, total)
    if total <= 0 then return 0 end
    return math.floor((elapsed * 100 / total) + 0.5)
end

local function countdown_line(label, state)
    local total = ms(state.total_ms)
    local remaining = ms(state.remaining_ms)
    if state.running and total > 0 then
        ui:add_line(label .. ": " .. fmt.progress_bar(remaining, total, BAR_WIDTH) .. " " .. pct(remaining, total) .. "% " .. duration(remaining))
    else
        ui:add_line(label .. ": idle")
    end
end

local function stopwatch_line(state)
    local elapsed = ms(state.elapsed_ms)
    if state.running or elapsed > 0 then
        ui:add_line("Stopwatch: " .. duration(elapsed))
    else
        ui:add_line("Stopwatch: idle")
    end
end

local function pomodoro_line(state)
    if state.running and state.type == "finished" then
        ui:add_line("Pomodoro: finished")
    elseif state.running then
        local label = "Pomodoro " .. (state.type or "focus")
        countdown_line(label, state)
        if state.task and state.task ~= "" then
            ui:add_line("Task: " .. state.task)
        end
    else
        ui:add_line("Pomodoro: idle")
    end
end

local function render()
    ui:set_title("Timer")
    countdown_line("Timer", clock:timer())
    stopwatch_line(clock:stopwatch())
    pomodoro_line(clock:pomodoro())
    ui:suggest_command("25m", "timer 25m")
    ui:suggest_command("+5m", "timer -add 5m")
    ui:suggest_command("+15m", "timer -add 15m")
    ui:suggest_command("stop", "timer -stop")
    ui:suggest_command("status", "timer -status")
    ui:suggest_command("watch", "stopwatch")
    ui:suggest_command("reset watch", "stopwatch -reset")
    ui:suggest_command("pomodoro", "pomodoro")
    ui:suggest_command("stop pomo", "pomodoro -stop")
end

function on_load() render() end
function on_resume() render() end
